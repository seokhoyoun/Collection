package list.run;

import list.view.BookMenu;

public class Run {

	public static void main(String[] args) {
		new BookMenu().mainMenu();
	}
}
